package inputdata;

public enum AllFeaturesEnum {
    Login,
    Register,
    Filter,
    Search,
    Purchase,
    Watch,
    Like,
    RateTheMovie,
    BuyPremiumAccount,
    BuyTokens,
    Logout
}
