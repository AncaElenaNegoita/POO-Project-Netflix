package inputdata;

public enum AllPagesEnum {
    UnauthenticatedHomePage,
    Login,
    Register,
    AuthenticatedHomePage,
    Movies,
    Upgrades,
    SeeDetails,
    Logout
}
